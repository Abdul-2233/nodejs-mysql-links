const indexCtrl = {};

indexCtrl.renderIndex = (req, res) => {
    res.render('index');
};

module.exports = indexCtrl;
